from django.http.response import HttpResponse
from django.shortcuts import redirect, render

from django.contrib import messages

from.models import Assignments
from.forms import AssignmentsForms



# Create your views here.
def home_view(request):
    return render(request,'web/home.html')


def about_view(request):
    return render(request,'web/about.html')


def webportal_view(request):
    return render(request,'web/webportal.html')


# assgning data create view
def assignment_view(request):
    if request.method=="POST":
        fm = AssignmentsForms(request.POST)
        if fm.is_valid():
            a1 = fm.cleaned_data['assign_id']
            a2 = fm.cleaned_data['emp_id']
            a3 = fm.cleaned_data['name_of_title']
            # a4 = fm.cleaned_data['create_date']
            # a5 = fm.cleaned_data['date_of_assigning_task']
            a6 = fm.cleaned_data['call_to_people']
            a7 = fm.cleaned_data['assigned_to']
            a8 = fm.cleaned_data['skill_required']
          

            data = Assignments(assign_id=a1,emp_id=a2,name_of_title=a3,
            call_to_people=a6,assigned_to=a7,skill_required=a8)
            
            messages.info(request, 'Your Account Has Succesfully Saved.')
            data.save()
            return redirect('assignment')
            
    else:
        fm = AssignmentsForms()
    assignment_all = Assignments.objects.all()   
    context = {"form":fm,'assignment_all':assignment_all}
    return render(request,'web/assignment.html',context)



# show assignment web page 

def showassignment_view(request):
    assignment_all = Assignments.objects.all()  
    context = {'assignment_all':assignment_all}
    return render(request,'web/showassignment.html',context)


# update the assignment Task..
def update_assignment(request,id):
    if request.method == "POST":
        pi = Assignments.objects.get(pk=id)
        fm = AssignmentsForms(request.POST,instance=pi)
        if fm.is_valid():
            fm.save(commit=True)
            # return redirect('/')
    else:
        pi = Assignments.objects.get(pk=id)
        fm = AssignmentsForms(instance=pi)
    return render(request,'web/assignment_update.html',{"form":fm})



# delete the form 
def delete_assignment(request,id):
    pi = Assignments.objects.get(pk=id)
    if request.method=="POST":
        pi.delete()
        return redirect('/')
    return HttpResponse("Your data has deleted ")
    # return render(request,'web/assignment_delete.html',context)






def Task_view(request):
    return render(request,'web/Task.html')


