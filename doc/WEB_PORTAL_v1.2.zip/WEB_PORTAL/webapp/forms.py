from django import forms

from .models import Assignments

class AssignmentsForms(forms.ModelForm):
    class Meta:
        model = Assignments
        fields = "__all__"
        # labels = ['id','assign_id','emp_id','name_of_title','create_date','date_of_assigning_task','','skill_required']
        labels = {'assign_id':'assigning Number','emp_id':'Employe Id','name_of_title':'Name Of Title',
        'create_date':'Create Date','date_of_assigning_task':'Assigning Task','call_to_people':'Assigning To Work People',
        '':'Assigned_work',
        'skill_required':'Skills Required',
        
        }

        widgets = {
        'assign_id':forms.NumberInput(attrs={'class':'form-control'}),
        'emp_id':forms.TextInput(attrs={'class':'form-control'}),
        'name_of_title':forms.TextInput(attrs={'class':'form-control',}),
        'create_date':forms.DateInput(attrs={'class':'form-control'}),
        'date_of_assigning_task':forms.DateTimeInput(attrs={'class':'form-control'}),
        'call_to_people':forms.Textarea(attrs={'class':'form-control','rows':4, 'cols':15}),
        'assigned_to':forms.Textarea(attrs={'class':'form-control','rows':1,'cols':1}),
        'skill_required':forms.TextInput(attrs={'class':'form-control',}),
        # 'uplode_attachement':forms.FileInput(attrs={'class':'form-control'}),

        
        }
