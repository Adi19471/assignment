from typing import Optional
from django.db import models
from django.contrib.auth.models import User

# Create your models here.
class Assignments(models.Model):
    assign_id             = models.IntegerField(auto_created=1)
    emp_id                = models.CharField(max_length=40)
    name_of_title         = models.CharField(max_length=50)
    create_date           = models.DateField(auto_now_add=True)
    date_of_assigning_task = models.DateTimeField(auto_now=True)
    call_to_people        = models.CharField(max_length=200)
    assigned_to           = models.TextField(max_length=250)
    skill_required        = models.CharField(max_length=120)
    # uplode_attachement    = models.FileField(upload_to="files/",default=True)
   

    def __str__(self):
       return self.name_of_title
   