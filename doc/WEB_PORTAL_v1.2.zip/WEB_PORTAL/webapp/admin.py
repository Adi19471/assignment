from django.contrib import admin

# Register your models here.
from.models import Assignments

# admin.site.register(Assignments)
@admin.register(Assignments)
class AssignmentsModel(admin.ModelAdmin):
    list_display = ['id','assign_id','emp_id','name_of_title','create_date','date_of_assigning_task','call_to_people','skill_required']

